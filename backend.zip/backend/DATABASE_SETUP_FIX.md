# Database Setup Fix - MySQL Not Running

## 🔴 Problem Identified
**MySQL server is not running** - Connection to port 3306 is being refused.

## ✅ Solution Options

### Option 1: Start MySQL Service (If Installed)

1. **Open Windows Services:**
   - Press `Win + R`
   - Type: `services.msc`
   - Press Enter

2. **Find MySQL Service:**
   - Look for services named:
     - `MySQL` or `MySQL80` or `MySQL57`
     - `MariaDB` (if using MariaDB)

3. **Start the Service:**
   - Right-click on MySQL service
   - Click "Start"
   - Wait for it to start (Status should change to "Running")

4. **Set to Auto-Start (Optional):**
   - Right-click → Properties
   - Set "Startup type" to "Automatic"
   - Click OK

5. **Run Setup Again:**
   ```powershell
   cd backend
   npm run setup-db
   ```

---

### Option 2: Install MySQL (If Not Installed)

#### Download MySQL:
1. Go to: https://dev.mysql.com/downloads/installer/
2. Download **"MySQL Installer for Windows"** (the larger file, ~400MB)
3. Run the installer

#### Installation Steps:
1. Choose **"Developer Default"** or **"Server only"**
2. Click "Execute" to install required components
3. Click "Next" through configuration
4. **Set root password** (remember this!)
5. Complete installation

#### After Installation:
1. MySQL service will start automatically
2. Update `backend/.env`:
   ```env
   DB_PASSWORD=your_mysql_root_password
   ```
3. Run setup:
   ```powershell
   npm run setup-db
   ```

---

### Option 3: Use XAMPP (Easiest for Beginners)

#### Install XAMPP:
1. Download: https://www.apachefriends.org/
2. Install XAMPP
3. Open **XAMPP Control Panel**
4. Click **"Start"** next to MySQL
5. Wait for MySQL to start (status turns green)

#### Setup Database:
1. Open browser: http://localhost/phpmyadmin
2. Click **"SQL"** tab
3. Copy contents of `backend/database/schema.sql`
4. Paste into SQL tab
5. Click **"Go"**

#### Configure .env:
```env
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=
DB_NAME=induslink_db
```
(XAMPP MySQL usually has no password)

---

### Option 4: Use MySQL Workbench (If Installed)

1. **Open MySQL Workbench**
2. **Connect to server** (usually "Local instance MySQL")
3. **File → Open SQL Script**
4. Navigate to: `backend/database/schema.sql`
5. **Click Execute** (lightning bolt icon) or press `Ctrl+Shift+Enter`
6. **Verify:** Check left sidebar for `induslink_db` database

---

## 🔍 Check What You Have

Run these commands to see what's installed:

```powershell
# Check for MySQL services
Get-Service | Where-Object {$_.Name -like "*mysql*"}

# Check for XAMPP
Test-Path "C:\xampp\mysql\bin\mysqld.exe"

# Check for MySQL Workbench
Get-ChildItem "C:\Program Files\MySQL" -ErrorAction SilentlyContinue
```

---

## 📝 Quick Setup Checklist

- [ ] MySQL is installed
- [ ] MySQL service is running
- [ ] `.env` file has correct password
- [ ] Port 3306 is accessible
- [ ] Database setup script runs successfully

---

## 🚀 After Database is Created

Once database setup succeeds, start the backend:

```powershell
cd backend
npm run dev
```

You should see:
```
✅ MySQL Database connected successfully
🚀 Server running on http://localhost:5000
```

---

## 💡 Recommended: Use XAMPP

**XAMPP is the easiest option** because:
- ✅ Simple installation
- ✅ Includes MySQL + phpMyAdmin (GUI)
- ✅ Easy to start/stop
- ✅ No password by default
- ✅ Perfect for development

**Steps:**
1. Install XAMPP
2. Start MySQL from XAMPP Control Panel
3. Use phpMyAdmin to run the SQL script
4. Done! ✅

