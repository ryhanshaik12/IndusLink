# MySQL Setup Guide for IndusLink

This guide will help you connect to MySQL and create the database for IndusLink.

## Method 1: Using the Setup Script (Recommended)

### Step 1: Configure .env File

1. Open `backend/.env` file
2. Update with your MySQL credentials:
   ```env
   DB_HOST=localhost
   DB_USER=root
   DB_PASSWORD=your_mysql_password
   DB_NAME=induslink_db
   PORT=5000
   JWT_SECRET=your_secret_key_here
   CORS_ORIGIN=http://localhost:5173
   ```

### Step 2: Run Setup Script

```powershell
cd backend
npm run setup-db
```

This will automatically:
- Connect to MySQL
- Create the database
- Create all tables

---

## Method 2: Manual MySQL Setup

### Step 1: Connect to MySQL

Open Command Prompt or PowerShell and connect to MySQL:

```bash
mysql -u root -p
```

Enter your MySQL password when prompted.

### Step 2: Create Database

Once connected to MySQL, run:

```sql
CREATE DATABASE IF NOT EXISTS induslink_db;
USE induslink_db;
```

### Step 3: Run Schema File

**Option A: From MySQL Command Line**

```sql
SOURCE C:/Users/Hp/Downloads/induslink-meta-react2/induslink-meta-react2/backend/database/schema.sql;
```

**Option B: From Command Line**

Exit MySQL first (type `exit`), then run:

```bash
mysql -u root -p induslink_db < C:/Users/Hp/Downloads/induslink-meta-react2/induslink-meta-react2/backend/database/schema.sql
```

### Step 4: Verify Tables Created

Connect to MySQL again and verify:

```sql
USE induslink_db;
SHOW TABLES;
```

You should see:
- users
- items
- orders
- order_items
- order_history
- cart

---

## Method 3: Using MySQL Workbench (GUI)

1. **Open MySQL Workbench**
2. **Connect to your MySQL server** (localhost, root user)
3. **Create a new query tab**
4. **Open the schema file**:
   - File → Open SQL Script
   - Navigate to: `backend/database/schema.sql`
5. **Execute the script** (Click the lightning bolt icon or press Ctrl+Shift+Enter)
6. **Verify**: Check the left sidebar - you should see `induslink_db` database with all tables

---

## Troubleshooting

### Issue: "Access denied for user 'root'@'localhost'"

**Solution:**
- Check your MySQL password in `.env` file
- Try resetting MySQL root password
- Or create a new MySQL user:

```sql
CREATE USER 'induslink_user'@'localhost' IDENTIFIED BY 'your_password';
GRANT ALL PRIVILEGES ON induslink_db.* TO 'induslink_user'@'localhost';
FLUSH PRIVILEGES;
```

Then update `.env`:
```env
DB_USER=induslink_user
DB_PASSWORD=your_password
```

### Issue: "Can't connect to MySQL server"

**Solution:**
- Make sure MySQL service is running:
  - Windows: Check Services (services.msc) → MySQL
  - Or run: `net start MySQL` (as Administrator)
- Check if MySQL is on port 3306 (default)
- Verify `DB_HOST=localhost` in `.env`

### Issue: "Database already exists"

**Solution:**
- This is fine! The script will continue
- Or drop and recreate:
  ```sql
  DROP DATABASE IF EXISTS induslink_db;
  CREATE DATABASE induslink_db;
  ```

### Issue: "Table already exists"

**Solution:**
- This is normal if you've run the script before
- The script ignores "already exists" errors
- Or manually drop tables:
  ```sql
  USE induslink_db;
  DROP TABLE IF EXISTS cart, order_history, order_items, orders, items, users;
  ```

---

## Verify Connection

After setup, test the connection:

```powershell
cd backend
npm run dev
```

You should see:
```
✅ MySQL Database connected successfully
🚀 Server running on http://localhost:5000
```

---

## Quick Reference

**MySQL Connection String Format:**
```
mysql://username:password@host:port/database
```

**Default MySQL Settings:**
- Host: localhost
- Port: 3306
- User: root
- Password: (your MySQL root password)

**Database Name:** induslink_db

**Tables Created:**
1. users - User accounts
2. items - Marketplace items
3. orders - Order records
4. order_items - Order line items
5. order_history - Status tracking
6. cart - Shopping cart

---

## Next Steps

After database setup:
1. Start backend server: `npm run dev`
2. Start frontend: `npm run dev` (in root directory)
3. Test registration/login
4. Check database to see data being stored

