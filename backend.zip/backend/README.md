# IndusLink Backend API

MySQL-based backend API for the IndusLink marketplace platform.

## Prerequisites

- Node.js (v14 or higher)
- MySQL (v5.7 or higher, or MariaDB)
- npm or yarn

## Installation

1. **Install dependencies:**
   ```bash
   cd backend
   npm install
   ```

2. **Configure environment variables:**
   ```bash
   cp .env.example .env
   ```
   
   Edit `.env` file with your database credentials:
   ```env
   DB_HOST=localhost
   DB_USER=root
   DB_PASSWORD=your_password
   DB_NAME=induslink_db
   PORT=5000
   JWT_SECRET=your_secret_key_here
   CORS_ORIGIN=http://localhost:5173
   ```

3. **Create MySQL database:**
   ```bash
   npm run setup-db
   ```
   
   Or manually run the SQL file:
   ```bash
   mysql -u root -p < database/schema.sql
   ```

## Running the Server

**Development mode (with auto-reload):**
```bash
npm run dev
```

**Production mode:**
```bash
npm start
```

The server will start on `http://localhost:5000`

## API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login user
- `GET /api/auth/me` - Get current user (requires token)

### Items
- `GET /api/items` - Get all items (with optional ?search= query)
- `GET /api/items/:id` - Get single item
- `POST /api/items` - Create item (seller only, requires auth)
- `PUT /api/items/:id` - Update item (seller only, own items)
- `DELETE /api/items/:id` - Delete item (seller only, own items)
- `GET /api/items/seller/my-items` - Get seller's items (requires auth)

### Cart
- `GET /api/cart` - Get user's cart (requires auth)
- `POST /api/cart/add` - Add item to cart (requires auth)
- `PUT /api/cart/update` - Update cart item quantity (requires auth)
- `DELETE /api/cart/remove/:itemId` - Remove item from cart (requires auth)
- `DELETE /api/cart/clear` - Clear cart (requires auth)

### Orders
- `POST /api/orders/create` - Create new order (buyer only, requires auth)
- `GET /api/orders/my-orders` - Get user's orders (requires auth)
- `GET /api/orders/:id` - Get single order (requires auth)
- `PUT /api/orders/:id/status` - Update order status (seller only, requires auth)

## Authentication

Most endpoints require authentication. Include the JWT token in the Authorization header:

```
Authorization: Bearer <your_token_here>
```

## Database Schema

- **users** - User accounts (buyers and sellers)
- **items** - Marketplace items/materials
- **orders** - Order records
- **order_items** - Order line items
- **order_history** - Order status change history
- **cart** - Shopping cart items

## Testing

You can test the API using:
- Postman
- curl
- Frontend application

Example curl request:
```bash
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"type":"buyer","name":"John Doe","email":"john@example.com","password":"password123"}'
```

## Notes

- Passwords are hashed using bcrypt
- JWT tokens expire after 7 days
- All timestamps are stored in UTC
- CORS is enabled for the frontend origin

