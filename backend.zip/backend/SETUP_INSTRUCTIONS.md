# MySQL Setup Instructions - No Command Line Required

Since MySQL command line is not in your PATH, here are the easiest ways to set up the database:

## Option 1: Use Node.js Setup Script (Recommended - No MySQL CLI needed)

This method uses Node.js to connect to MySQL directly - you don't need the `mysql` command!

### Step 1: Configure .env File

1. Open `backend/.env` file in a text editor
2. Update with your MySQL credentials:

```env
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_mysql_password_here
DB_NAME=induslink_db
PORT=5000
JWT_SECRET=change_this_to_a_random_string
CORS_ORIGIN=http://localhost:5173
```

**Important:** 
- Replace `your_mysql_password_here` with your actual MySQL root password
- If you don't have a password, leave it empty: `DB_PASSWORD=`

### Step 2: Run Setup Script

```powershell
cd backend
npm run setup-db
```

This will automatically:
- Connect to MySQL using Node.js
- Create the database
- Create all tables

---

## Option 2: Install MySQL (If Not Installed)

### Download MySQL:

1. Go to: https://dev.mysql.com/downloads/installer/
2. Download "MySQL Installer for Windows"
3. Run the installer
4. Choose "Developer Default" or "Server only"
5. Set a root password (remember this!)
6. Complete installation

### After Installation:

1. MySQL will be added to PATH automatically
2. You can then use: `mysql -u root -p`
3. Or continue with Option 1 (Node.js script)

---

## Option 3: Use MySQL Workbench (GUI)

If you have MySQL Workbench installed:

1. **Open MySQL Workbench**
2. **Connect to your server** (usually "Local instance MySQL")
3. **Click "File" → "Open SQL Script"**
4. **Navigate to:** `backend/database/schema.sql`
5. **Click Execute** (lightning bolt icon) or press `Ctrl+Shift+Enter`
6. **Verify:** Check left sidebar for `induslink_db` database

---

## Option 4: Use XAMPP/WAMP (If You Have It)

If you have XAMPP or WAMP installed:

1. **Start MySQL** from XAMPP/WAMP control panel
2. **Open phpMyAdmin** (usually http://localhost/phpmyadmin)
3. **Click "SQL" tab**
4. **Copy and paste** the contents of `backend/database/schema.sql`
5. **Click "Go"**

---

## Quick Test After Setup

Once database is created, test the connection:

```powershell
cd backend
npm run dev
```

You should see:
```
✅ MySQL Database connected successfully
🚀 Server running on http://localhost:5000
```

---

## Troubleshooting

### "Access denied for user 'root'@'localhost'"

**Solutions:**
1. Check your password in `.env` file
2. Try empty password: `DB_PASSWORD=`
3. Reset MySQL root password
4. Create a new MySQL user (see below)

### "Can't connect to MySQL server"

**Solutions:**
1. Make sure MySQL service is running:
   - Open Services (Win+R → `services.msc`)
   - Find "MySQL" service
   - Right-click → Start
2. Check if MySQL is on port 3306
3. Verify `DB_HOST=localhost` in `.env`

### Create New MySQL User (If Root Doesn't Work)

If you can access MySQL through Workbench or phpMyAdmin:

```sql
CREATE USER 'induslink_user'@'localhost' IDENTIFIED BY 'your_password';
GRANT ALL PRIVILEGES ON induslink_db.* TO 'induslink_user'@'localhost';
FLUSH PRIVILEGES;
```

Then update `.env`:
```env
DB_USER=induslink_user
DB_PASSWORD=your_password
```

---

## Recommended: Use Option 1 (Node.js Script)

The Node.js setup script is the easiest because:
- ✅ No need for MySQL command line
- ✅ Works if MySQL is installed anywhere
- ✅ Automatic error handling
- ✅ Already have Node.js installed

Just make sure your `.env` file has the correct MySQL credentials!

