const express = require('express');
const router = express.Router();
const pool = require('../config/database');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

// Register new user
router.post('/register', async (req, res) => {
  try {
    const { type, name, email, password } = req.body;

    // Validation
    if (!type || !name || !email || !password) {
      return res.status(400).json({ success: false, message: 'All fields are required' });
    }

    if (!['buyer', 'seller'].includes(type)) {
      return res.status(400).json({ success: false, message: 'Invalid user type' });
    }

    if (password.length < 6) {
      return res.status(400).json({ success: false, message: 'Password must be at least 6 characters' });
    }

    // Check if email already exists
    const [existing] = await pool.execute(
      'SELECT id FROM users WHERE email = ?',
      [email]
    );

    if (existing.length > 0) {
      return res.status(400).json({ success: false, message: 'Email already registered' });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Insert user
    const [result] = await pool.execute(
      'INSERT INTO users (name, email, password, type, verified) VALUES (?, ?, ?, ?, ?)',
      [name, email, hashedPassword, type, true]
    );

    const userId = result.insertId;

    // Get created user (without password)
    const [users] = await pool.execute(
      'SELECT id, name, email, type, verified, profile_picture, created_at FROM users WHERE id = ?',
      [userId]
    );

    // Generate JWT token
    const token = jwt.sign(
      { id: userId, email, type },
      process.env.JWT_SECRET || 'default_secret',
      { expiresIn: '7d' }
    );

    res.status(201).json({
      success: true,
      message: 'User registered successfully',
      user: users[0],
      token
    });
  } catch (error) {
    console.error('Register error:', error);
    res.status(500).json({ success: false, message: 'Registration failed' });
  }
});

// Login user
router.post('/login', async (req, res) => {
  try {
    const { type, email, password } = req.body;

    if (!type || !email || !password) {
      return res.status(400).json({ success: false, message: 'All fields are required' });
    }

    // Find user
    const [users] = await pool.execute(
      'SELECT id, name, email, password, type, verified, profile_picture, created_at FROM users WHERE email = ? AND type = ?',
      [email, type]
    );

    if (users.length === 0) {
      return res.status(401).json({ success: false, message: 'Invalid email or password' });
    }

    const user = users[0];

    // Verify password
    const isValidPassword = await bcrypt.compare(password, user.password);
    if (!isValidPassword) {
      return res.status(401).json({ success: false, message: 'Invalid email or password' });
    }

    // Remove password from response
    delete user.password;

    // Generate JWT token
    const token = jwt.sign(
      { id: user.id, email: user.email, type: user.type },
      process.env.JWT_SECRET || 'default_secret',
      { expiresIn: '7d' }
    );

    res.json({
      success: true,
      message: 'Login successful',
      user,
      token
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ success: false, message: 'Login failed' });
  }
});

// Get current user (verify token)
router.get('/me', async (req, res) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];

    if (!token) {
      return res.status(401).json({ success: false, message: 'No token provided' });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'default_secret');

    const [users] = await pool.execute(
      'SELECT id, name, email, type, verified, profile_picture, created_at FROM users WHERE id = ?',
      [decoded.id]
    );

    if (users.length === 0) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }

    res.json({
      success: true,
      user: users[0]
    });
  } catch (error) {
    console.error('Auth check error:', error);
    res.status(401).json({ success: false, message: 'Invalid token' });
  }
});

module.exports = router;

