const express = require('express');
const router = express.Router();
const pool = require('../config/database');
const authenticate = require('../middleware/authenticate');

// Get user's cart
router.get('/', authenticate, async (req, res) => {
  try {
    const [cartItems] = await pool.execute(
      `SELECT 
        c.id, c.quantity,
        i.id as item_id, i.title, i.description, i.qty_available as qtyAvailable,
        i.price_per_ton as pricePerTon, i.image
      FROM cart c
      JOIN items i ON c.item_id = i.id
      WHERE c.user_id = ?
      ORDER BY c.created_at DESC`,
      [req.user.id]
    );

    const formattedCart = cartItems.map(item => ({
      id: item.item_id,
      title: item.title,
      description: item.description,
      qtyAvailable: parseFloat(item.qtyAvailable),
      pricePerTon: parseFloat(item.pricePerTon),
      image: item.image,
      qty: parseFloat(item.quantity)
    }));

    res.json({ success: true, cart: formattedCart });
  } catch (error) {
    console.error('Get cart error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch cart' });
  }
});

// Add item to cart
router.post('/add', authenticate, async (req, res) => {
  try {
    const { itemId, quantity } = req.body;

    if (!itemId || !quantity || quantity <= 0) {
      return res.status(400).json({ success: false, message: 'Item ID and valid quantity are required' });
    }

    // Check if item exists
    const [items] = await pool.execute(
      'SELECT id, qty_available FROM items WHERE id = ?',
      [itemId]
    );

    if (items.length === 0) {
      return res.status(404).json({ success: false, message: 'Item not found' });
    }

    if (parseFloat(quantity) > parseFloat(items[0].qty_available)) {
      return res.status(400).json({ success: false, message: 'Quantity exceeds available stock' });
    }

    // Check if item already in cart
    const [existing] = await pool.execute(
      'SELECT id, quantity FROM cart WHERE user_id = ? AND item_id = ?',
      [req.user.id, itemId]
    );

    if (existing.length > 0) {
      // Update quantity
      const newQuantity = parseFloat(existing[0].quantity) + parseFloat(quantity);
      await pool.execute(
        'UPDATE cart SET quantity = ? WHERE id = ?',
        [newQuantity, existing[0].id]
      );
    } else {
      // Add new item
      await pool.execute(
        'INSERT INTO cart (user_id, item_id, quantity) VALUES (?, ?, ?)',
        [req.user.id, itemId, quantity]
      );
    }

    res.json({ success: true, message: 'Item added to cart' });
  } catch (error) {
    console.error('Add to cart error:', error);
    res.status(500).json({ success: false, message: 'Failed to add item to cart' });
  }
});

// Update cart item quantity
router.put('/update', authenticate, async (req, res) => {
  try {
    const { itemId, quantity } = req.body;

    if (!itemId || quantity === undefined) {
      return res.status(400).json({ success: false, message: 'Item ID and quantity are required' });
    }

    if (quantity <= 0) {
      // Remove item if quantity is 0 or less
      await pool.execute(
        'DELETE FROM cart WHERE user_id = ? AND item_id = ?',
        [req.user.id, itemId]
      );
      return res.json({ success: true, message: 'Item removed from cart' });
    }

    // Check if item exists in cart
    const [existing] = await pool.execute(
      'SELECT id FROM cart WHERE user_id = ? AND item_id = ?',
      [req.user.id, itemId]
    );

    if (existing.length === 0) {
      return res.status(404).json({ success: false, message: 'Item not found in cart' });
    }

    // Check available stock
    const [items] = await pool.execute(
      'SELECT qty_available FROM items WHERE id = ?',
      [itemId]
    );

    if (parseFloat(quantity) > parseFloat(items[0].qty_available)) {
      return res.status(400).json({ success: false, message: 'Quantity exceeds available stock' });
    }

    // Update quantity
    await pool.execute(
      'UPDATE cart SET quantity = ? WHERE user_id = ? AND item_id = ?',
      [quantity, req.user.id, itemId]
    );

    res.json({ success: true, message: 'Cart updated' });
  } catch (error) {
    console.error('Update cart error:', error);
    res.status(500).json({ success: false, message: 'Failed to update cart' });
  }
});

// Remove item from cart
router.delete('/remove/:itemId', authenticate, async (req, res) => {
  try {
    const { itemId } = req.params;

    await pool.execute(
      'DELETE FROM cart WHERE user_id = ? AND item_id = ?',
      [req.user.id, itemId]
    );

    res.json({ success: true, message: 'Item removed from cart' });
  } catch (error) {
    console.error('Remove from cart error:', error);
    res.status(500).json({ success: false, message: 'Failed to remove item from cart' });
  }
});

// Clear cart
router.delete('/clear', authenticate, async (req, res) => {
  try {
    await pool.execute('DELETE FROM cart WHERE user_id = ?', [req.user.id]);

    res.json({ success: true, message: 'Cart cleared' });
  } catch (error) {
    console.error('Clear cart error:', error);
    res.status(500).json({ success: false, message: 'Failed to clear cart' });
  }
});

module.exports = router;

