const express = require('express');
const router = express.Router();
const pool = require('../config/database');
const authenticate = require('../middleware/authenticate');

// Get all items (marketplace)
router.get('/', async (req, res) => {
  try {
    const { search } = req.query;
    
    let query = `
      SELECT 
        i.id, i.title, i.description, i.qty_available as qtyAvailable, 
        i.price_per_ton as pricePerTon, i.image, i.created_at as createdAt,
        u.name as sellerName, u.id as sellerId
      FROM items i
      JOIN users u ON i.seller_id = u.id
      WHERE 1=1
    `;
    
    const params = [];
    
    if (search) {
      query += ' AND (i.title LIKE ? OR i.description LIKE ?)';
      const searchTerm = `%${search}%`;
      params.push(searchTerm, searchTerm);
    }
    
    query += ' ORDER BY i.created_at DESC';
    
    const [items] = await pool.execute(query, params);
    
    // Format items to match frontend structure
    const formattedItems = items.map(item => ({
      id: item.id,
      title: item.title,
      description: item.description,
      qtyAvailable: parseFloat(item.qtyAvailable),
      pricePerTon: parseFloat(item.pricePerTon),
      image: item.image,
      sellerId: item.sellerId,
      sellerName: item.sellerName,
      createdAt: item.createdAt
    }));
    
    res.json({ success: true, items: formattedItems });
  } catch (error) {
    console.error('Get items error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch items' });
  }
});

// Get single item
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    const [items] = await pool.execute(
      `SELECT 
        i.id, i.title, i.description, i.qty_available as qtyAvailable, 
        i.price_per_ton as pricePerTon, i.image, i.created_at as createdAt,
        u.name as sellerName, u.id as sellerId
      FROM items i
      JOIN users u ON i.seller_id = u.id
      WHERE i.id = ?`,
      [id]
    );
    
    if (items.length === 0) {
      return res.status(404).json({ success: false, message: 'Item not found' });
    }
    
    const item = items[0];
    res.json({
      success: true,
      item: {
        id: item.id,
        title: item.title,
        description: item.description,
        qtyAvailable: parseFloat(item.qtyAvailable),
        pricePerTon: parseFloat(item.pricePerTon),
        image: item.image,
        sellerId: item.sellerId,
        sellerName: item.sellerName,
        createdAt: item.createdAt
      }
    });
  } catch (error) {
    console.error('Get item error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch item' });
  }
});

// Create new item (seller only)
router.post('/', authenticate, async (req, res) => {
  try {
    if (req.user.type !== 'seller') {
      return res.status(403).json({ success: false, message: 'Only sellers can create items' });
    }
    
    const { title, description, qtyAvailable, pricePerTon, image } = req.body;
    
    if (!title || !description || !qtyAvailable || !pricePerTon) {
      return res.status(400).json({ success: false, message: 'All required fields must be provided' });
    }
    
    const itemId = 'mat-' + Date.now();
    
    await pool.execute(
      'INSERT INTO items (id, seller_id, title, description, qty_available, price_per_ton, image) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [itemId, req.user.id, title, description, qtyAvailable, pricePerTon, image || null]
    );
    
    // Get created item
    const [items] = await pool.execute(
      'SELECT id, title, description, qty_available as qtyAvailable, price_per_ton as pricePerTon, image FROM items WHERE id = ?',
      [itemId]
    );
    
    res.status(201).json({
      success: true,
      message: 'Item created successfully',
      item: {
        ...items[0],
        qtyAvailable: parseFloat(items[0].qtyAvailable),
        pricePerTon: parseFloat(items[0].pricePerTon)
      }
    });
  } catch (error) {
    console.error('Create item error:', error);
    res.status(500).json({ success: false, message: 'Failed to create item' });
  }
});

// Update item (seller only, own items)
router.put('/:id', authenticate, async (req, res) => {
  try {
    if (req.user.type !== 'seller') {
      return res.status(403).json({ success: false, message: 'Only sellers can update items' });
    }
    
    const { id } = req.params;
    const { title, description, qtyAvailable, pricePerTon, image } = req.body;
    
    // Check if item exists and belongs to seller
    const [items] = await pool.execute(
      'SELECT seller_id FROM items WHERE id = ?',
      [id]
    );
    
    if (items.length === 0) {
      return res.status(404).json({ success: false, message: 'Item not found' });
    }
    
    if (items[0].seller_id !== req.user.id) {
      return res.status(403).json({ success: false, message: 'You can only update your own items' });
    }
    
    // Update item
    await pool.execute(
      'UPDATE items SET title = ?, description = ?, qty_available = ?, price_per_ton = ?, image = ? WHERE id = ?',
      [title, description, qtyAvailable, pricePerTon, image || null, id]
    );
    
    // Get updated item
    const [updated] = await pool.execute(
      'SELECT id, title, description, qty_available as qtyAvailable, price_per_ton as pricePerTon, image FROM items WHERE id = ?',
      [id]
    );
    
    res.json({
      success: true,
      message: 'Item updated successfully',
      item: {
        ...updated[0],
        qtyAvailable: parseFloat(updated[0].qtyAvailable),
        pricePerTon: parseFloat(updated[0].pricePerTon)
      }
    });
  } catch (error) {
    console.error('Update item error:', error);
    res.status(500).json({ success: false, message: 'Failed to update item' });
  }
});

// Delete item (seller only, own items)
router.delete('/:id', authenticate, async (req, res) => {
  try {
    if (req.user.type !== 'seller') {
      return res.status(403).json({ success: false, message: 'Only sellers can delete items' });
    }
    
    const { id } = req.params;
    
    // Check if item exists and belongs to seller
    const [items] = await pool.execute(
      'SELECT seller_id FROM items WHERE id = ?',
      [id]
    );
    
    if (items.length === 0) {
      return res.status(404).json({ success: false, message: 'Item not found' });
    }
    
    if (items[0].seller_id !== req.user.id) {
      return res.status(403).json({ success: false, message: 'You can only delete your own items' });
    }
    
    await pool.execute('DELETE FROM items WHERE id = ?', [id]);
    
    res.json({ success: true, message: 'Item deleted successfully' });
  } catch (error) {
    console.error('Delete item error:', error);
    res.status(500).json({ success: false, message: 'Failed to delete item' });
  }
});

// Get seller's items
router.get('/seller/my-items', authenticate, async (req, res) => {
  try {
    if (req.user.type !== 'seller') {
      return res.status(403).json({ success: false, message: 'Only sellers can view their items' });
    }
    
    const [items] = await pool.execute(
      'SELECT id, title, description, qty_available as qtyAvailable, price_per_ton as pricePerTon, image, created_at as createdAt FROM items WHERE seller_id = ? ORDER BY created_at DESC',
      [req.user.id]
    );
    
    const formattedItems = items.map(item => ({
      ...item,
      qtyAvailable: parseFloat(item.qtyAvailable),
      pricePerTon: parseFloat(item.pricePerTon)
    }));
    
    res.json({ success: true, items: formattedItems });
  } catch (error) {
    console.error('Get seller items error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch items' });
  }
});

module.exports = router;

