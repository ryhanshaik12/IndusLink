const express = require('express');
const router = express.Router();
const pool = require('../config/database');
const authenticate = require('../middleware/authenticate');

// Create new order
router.post('/create', authenticate, async (req, res) => {
  try {
    if (req.user.type !== 'buyer') {
      return res.status(403).json({ success: false, message: 'Only buyers can create orders' });
    }

    const { items, note, paymentMethod, txId, paymentId } = req.body;

    if (!items || items.length === 0) {
      return res.status(400).json({ success: false, message: 'Cart is empty' });
    }

    // Calculate totals
    let total = 0;
    for (const item of items) {
      const itemTotal = parseFloat(item.pricePerTon) * parseFloat(item.qty);
      total += itemTotal;
    }
    const tax = Math.round(total * 0.18);
    const finalTotal = total + tax;

    // Create order
    const orderId = 'ORD' + Date.now();
    
    await pool.execute(
      `INSERT INTO orders (id, buyer_id, buyer_name, total, tax, final_total, status, tx_id, payment_id, payment_method, note)
       VALUES (?, ?, ?, ?, ?, ?, 'Placed', ?, ?, ?, ?)`,
      [orderId, req.user.id, req.user.name, total, tax, finalTotal, txId || null, paymentId || null, paymentMethod || 'razorpay', note || null]
    );

    // Add order items
    for (const item of items) {
      const subtotal = parseFloat(item.pricePerTon) * parseFloat(item.qty);
      await pool.execute(
        `INSERT INTO order_items (order_id, item_id, item_title, quantity, price_per_ton, subtotal)
         VALUES (?, ?, ?, ?, ?, ?)`,
        [orderId, item.id, item.title, item.qty, item.pricePerTon, subtotal]
      );

      // Update item quantity
      await pool.execute(
        'UPDATE items SET qty_available = qty_available - ? WHERE id = ?',
        [item.qty, item.id]
      );
    }

    // Add order history
    await pool.execute(
      'INSERT INTO order_history (order_id, status) VALUES (?, ?)',
      [orderId, 'Placed']
    );

    // Clear user's cart
    await pool.execute('DELETE FROM cart WHERE user_id = ?', [req.user.id]);

    // Get created order
    const [orders] = await pool.execute(
      `SELECT id, buyer_id, buyer_name, total, tax, final_total, status, tx_id, payment_id, payment_method, note, created_at
       FROM orders WHERE id = ?`,
      [orderId]
    );

    const [orderItems] = await pool.execute(
      'SELECT item_id as id, item_title as title, quantity as qty, price_per_ton as pricePerTon, subtotal FROM order_items WHERE order_id = ?',
      [orderId]
    );

    const order = {
      ...orders[0],
      total: parseFloat(orders[0].total),
      tax: parseFloat(orders[0].tax),
      finalTotal: parseFloat(orders[0].final_total),
      items: orderItems.map(item => ({
        ...item,
        qty: parseFloat(item.qty),
        pricePerTon: parseFloat(item.pricePerTon),
        subtotal: parseFloat(item.subtotal)
      }))
    };

    res.status(201).json({
      success: true,
      message: 'Order created successfully',
      order
    });
  } catch (error) {
    console.error('Create order error:', error);
    res.status(500).json({ success: false, message: 'Failed to create order' });
  }
});

// Get user's orders
router.get('/my-orders', authenticate, async (req, res) => {
  try {
    let query, params;

    if (req.user.type === 'buyer') {
      query = `SELECT id, buyer_id, buyer_name, total, tax, final_total, status, tx_id, payment_id, payment_method, note, created_at
               FROM orders WHERE buyer_id = ? ORDER BY created_at DESC`;
      params = [req.user.id];
    } else {
      // Seller sees all orders that contain their items
      query = `SELECT DISTINCT o.id, o.buyer_id, o.buyer_name, o.total, o.tax, o.final_total, o.status, o.tx_id, o.payment_id, o.payment_method, o.note, o.created_at
               FROM orders o
               JOIN order_items oi ON o.id = oi.order_id
               JOIN items i ON oi.item_id = i.id
               WHERE i.seller_id = ?
               ORDER BY o.created_at DESC`;
      params = [req.user.id];
    }

    const [orders] = await pool.execute(query, params);

    // Get order items for each order
    const ordersWithItems = await Promise.all(
      orders.map(async (order) => {
        const [orderItems] = await pool.execute(
          `SELECT oi.item_id as id, oi.item_title as title, oi.quantity as qty, oi.price_per_ton as pricePerTon, oi.subtotal
           FROM order_items oi
           WHERE oi.order_id = ?`,
          [order.id]
        );

        // Get order history
        const [history] = await pool.execute(
          'SELECT status, changed_at as at FROM order_history WHERE order_id = ? ORDER BY changed_at ASC',
          [order.id]
        );

        return {
          id: order.id,
          buyerId: order.buyer_id,
          buyerName: order.buyer_name,
          total: parseFloat(order.total),
          tax: parseFloat(order.tax),
          finalTotal: parseFloat(order.final_total),
          status: order.status,
          txId: order.tx_id,
          paymentId: order.payment_id,
          paymentMethod: order.payment_method,
          note: order.note,
          createdAt: order.created_at,
          items: orderItems.map(item => ({
            ...item,
            qty: parseFloat(item.qty),
            pricePerTon: parseFloat(item.pricePerTon),
            subtotal: parseFloat(item.subtotal)
          })),
          history: history.map(h => ({
            status: h.status,
            at: h.at
          }))
        };
      })
    );

    res.json({ success: true, orders: ordersWithItems });
  } catch (error) {
    console.error('Get orders error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch orders' });
  }
});

// Get single order
router.get('/:id', authenticate, async (req, res) => {
  try {
    const { id } = req.params;

    const [orders] = await pool.execute(
      `SELECT id, buyer_id, buyer_name, total, tax, final_total, status, tx_id, payment_id, payment_method, note, created_at
       FROM orders WHERE id = ?`,
      [id]
    );

    if (orders.length === 0) {
      return res.status(404).json({ success: false, message: 'Order not found' });
    }

    const order = orders[0];

    // Check permissions
    if (req.user.type === 'buyer' && order.buyer_id !== req.user.id) {
      return res.status(403).json({ success: false, message: 'Access denied' });
    }

    // Get order items
    const [orderItems] = await pool.execute(
      `SELECT oi.item_id as id, oi.item_title as title, oi.quantity as qty, oi.price_per_ton as pricePerTon, oi.subtotal
       FROM order_items oi
       WHERE oi.order_id = ?`,
      [id]
    );

    // Get order history
    const [history] = await pool.execute(
      'SELECT status, changed_at as at FROM order_history WHERE order_id = ? ORDER BY changed_at ASC',
      [id]
    );

    res.json({
      success: true,
      order: {
        id: order.id,
        buyerId: order.buyer_id,
        buyerName: order.buyer_name,
        total: parseFloat(order.total),
        tax: parseFloat(order.tax),
        finalTotal: parseFloat(order.final_total),
        status: order.status,
        txId: order.tx_id,
        paymentId: order.payment_id,
        paymentMethod: order.payment_method,
        note: order.note,
        createdAt: order.created_at,
        items: orderItems.map(item => ({
          ...item,
          qty: parseFloat(item.qty),
          pricePerTon: parseFloat(item.pricePerTon),
          subtotal: parseFloat(item.subtotal)
        })),
        history: history.map(h => ({
          status: h.status,
          at: h.at
        }))
      }
    });
  } catch (error) {
    console.error('Get order error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch order' });
  }
});

// Update order status (seller only)
router.put('/:id/status', authenticate, async (req, res) => {
  try {
    if (req.user.type !== 'seller') {
      return res.status(403).json({ success: false, message: 'Only sellers can update order status' });
    }

    const { id } = req.params;
    const { status } = req.body;

    const validStatuses = ['Placed', 'Dispatched', 'In Transit', 'Delivered'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({ success: false, message: 'Invalid status' });
    }

    // Check if order exists and contains seller's items
    const [orders] = await pool.execute(
      `SELECT o.id, o.status
       FROM orders o
       JOIN order_items oi ON o.id = oi.order_id
       JOIN items i ON oi.item_id = i.id
       WHERE o.id = ? AND i.seller_id = ?`,
      [id, req.user.id]
    );

    if (orders.length === 0) {
      return res.status(404).json({ success: false, message: 'Order not found or access denied' });
    }

    // Update status
    await pool.execute(
      'UPDATE orders SET status = ? WHERE id = ?',
      [status, id]
    );

    // Add to history
    await pool.execute(
      'INSERT INTO order_history (order_id, status) VALUES (?, ?)',
      [id, status]
    );

    res.json({ success: true, message: 'Order status updated' });
  } catch (error) {
    console.error('Update order status error:', error);
    res.status(500).json({ success: false, message: 'Failed to update order status' });
  }
});

module.exports = router;

