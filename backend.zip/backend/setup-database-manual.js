const mysql = require('mysql2/promise');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

async function setupDatabase() {
  let connection;
  
  console.log('🔍 Attempting to connect to MySQL...');
  console.log(`   Host: ${process.env.DB_HOST || 'localhost'}`);
  console.log(`   User: ${process.env.DB_USER || 'root'}`);
  console.log(`   Password: ${process.env.DB_PASSWORD ? '***' : '(empty)'}`);
  console.log('');
  
  try {
    // First, try to connect without database
    console.log('📡 Connecting to MySQL server...');
    connection = await mysql.createConnection({
      host: process.env.DB_HOST || 'localhost',
      user: process.env.DB_USER || 'root',
      password: process.env.DB_PASSWORD || '',
      connectTimeout: 5000
    });

    console.log('✅ Connected to MySQL server successfully!');
    console.log('');

    // Create database
    console.log('📦 Creating database...');
    await connection.query(`CREATE DATABASE IF NOT EXISTS ${process.env.DB_NAME || 'induslink_db'}`);
    console.log(`✅ Database '${process.env.DB_NAME || 'induslink_db'}' created/verified`);
    
    // Use the database
    await connection.query(`USE ${process.env.DB_NAME || 'induslink_db'}`);
    console.log('');

    // Read and execute schema
    console.log('📄 Reading schema file...');
    const schemaPath = path.join(__dirname, 'database', 'schema.sql');
    
    if (!fs.existsSync(schemaPath)) {
      throw new Error(`Schema file not found at: ${schemaPath}`);
    }
    
    const schema = fs.readFileSync(schemaPath, 'utf8');
    console.log('✅ Schema file loaded');
    console.log('');

    // Split by semicolons and execute each statement
    console.log('🔨 Creating tables...');
    const statements = schema
      .split(';')
      .map(s => s.trim())
      .filter(s => s.length > 0 && !s.startsWith('--') && !s.toLowerCase().startsWith('create database'));

    let successCount = 0;
    let skipCount = 0;
    
    for (const statement of statements) {
      if (statement) {
        try {
          await connection.query(statement);
          successCount++;
        } catch (err) {
          // Ignore "already exists" errors
          if (err.message.includes('already exists') || err.message.includes('Duplicate')) {
            skipCount++;
          } else {
            console.warn(`⚠️  Warning: ${err.message}`);
          }
        }
      }
    }

    console.log(`✅ Created ${successCount} tables`);
    if (skipCount > 0) {
      console.log(`ℹ️  Skipped ${skipCount} (already exist)`);
    }
    console.log('');

    // Verify tables
    console.log('🔍 Verifying tables...');
    const [tables] = await connection.query('SHOW TABLES');
    console.log(`✅ Found ${tables.length} tables:`);
    tables.forEach(table => {
      const tableName = Object.values(table)[0];
      console.log(`   - ${tableName}`);
    });
    
    console.log('');
    console.log('✅ Database setup completed successfully!');
    console.log('');
    console.log('📝 Next steps:');
    console.log('   1. Start the backend server: npm run dev');
    console.log('   2. Start the frontend: npm run dev (in root directory)');
    console.log('   3. Test registration/login in the app');
    
  } catch (error) {
    console.error('');
    console.error('❌ Database setup error:', error.message);
    console.error('');
    console.error('📋 Troubleshooting Guide:');
    console.error('');
    
    if (error.code === 'ECONNREFUSED') {
      console.error('⚠️  CONNECTION REFUSED');
      console.error('   → MySQL server is not running or not accessible');
      console.error('   → Solutions:');
      console.error('      1. Start MySQL service (check Windows Services)');
      console.error('      2. Install MySQL if not installed');
      console.error('      3. Check if MySQL is on a different port');
    } else if (error.code === 'ER_ACCESS_DENIED_ERROR') {
      console.error('⚠️  ACCESS DENIED');
      console.error('   → Wrong username or password');
      console.error('   → Solutions:');
      console.error('      1. Check .env file has correct DB_USER and DB_PASSWORD');
      console.error('      2. Try resetting MySQL root password');
      console.error('      3. Create a new MySQL user with proper permissions');
    } else if (error.code === 'ENOTFOUND') {
      console.error('⚠️  HOST NOT FOUND');
      console.error('   → Cannot find MySQL server');
      console.error('   → Solutions:');
      console.error('      1. Check DB_HOST in .env file (should be "localhost")');
      console.error('      2. Verify MySQL is installed and running');
    } else {
      console.error('⚠️  UNKNOWN ERROR');
      console.error('   → Error code:', error.code);
      console.error('   → Full error:', error);
    }
    
    console.error('');
    console.error('💡 Alternative Setup Methods:');
    console.error('   1. Use MySQL Workbench:');
    console.error('      - Open MySQL Workbench');
    console.error('      - Connect to server');
    console.error('      - File → Open SQL Script → database/schema.sql');
    console.error('      - Execute the script');
    console.error('');
    console.error('   2. Use phpMyAdmin (if using XAMPP/WAMP):');
    console.error('      - Open http://localhost/phpmyadmin');
    console.error('      - Click SQL tab');
    console.error('      - Copy contents of database/schema.sql');
    console.error('      - Paste and execute');
    console.error('');
    console.error('   3. Manual MySQL command (if MySQL is in PATH):');
    console.error('      - mysql -u root -p');
    console.error('      - SOURCE path/to/database/schema.sql;');
    
    process.exit(1);
  } finally {
    if (connection) {
      await connection.end();
      console.log('');
      console.log('🔌 Connection closed');
    }
  }
}

setupDatabase();

