const mysql = require('mysql2/promise');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

async function setupDatabase() {
  let connection;
  
  try {
    // Connect without database first
    connection = await mysql.createConnection({
      host: process.env.DB_HOST || 'localhost',
      user: process.env.DB_USER || 'root',
      password: process.env.DB_PASSWORD || ''
    });

    console.log('✅ Connected to MySQL server');

    // Read and execute schema
    const schemaPath = path.join(__dirname, 'database', 'schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf8');

    // Split by semicolons and execute each statement
    const statements = schema
      .split(';')
      .map(s => s.trim())
      .filter(s => s.length > 0 && !s.startsWith('--'));

    for (const statement of statements) {
      if (statement) {
        try {
          await connection.query(statement);
        } catch (err) {
          // Ignore "already exists" errors
          if (!err.message.includes('already exists') && !err.message.includes('Duplicate')) {
            console.warn('Warning:', err.message);
          }
        }
      }
    }

    console.log('✅ Database schema created successfully');
    console.log('✅ Tables created: users, items, orders, order_items, order_history, cart');
    
  } catch (error) {
    console.error('❌ Database setup error:', error.message);
    console.error('\n📋 Troubleshooting:');
    console.error('1. Make sure MySQL is installed and running');
    console.error('2. Check your .env file has correct credentials');
    console.error('3. Verify MySQL service is running (check Services)');
    console.error('4. Try connecting manually: mysql -u root -p');
    console.error('\n💡 Alternative: Use MySQL Workbench or phpMyAdmin to run database/schema.sql manually');
    if (error.code === 'ECONNREFUSED') {
      console.error('\n⚠️  Connection refused - MySQL might not be running!');
    } else if (error.code === 'ER_ACCESS_DENIED_ERROR') {
      console.error('\n⚠️  Access denied - Check your username and password in .env file!');
    }
    process.exit(1);
  } finally {
    if (connection) {
      await connection.end();
    }
  }
}

setupDatabase();

